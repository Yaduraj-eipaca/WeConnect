<?php

include("database/db_conection.php");
$answer_id=$_GET['answer'];
$answer_doubt="insert into question (answer) VALUE ('$answer_id')";
$run=mysqli_query($dbcon,$answer_doubt);
if($run)
{
//javascript function to open in the same window
    echo "<script>window.open('student_queries.php?deleted=user has been Answer','_self')</script>";
    
}

?>
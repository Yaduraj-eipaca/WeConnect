<html>
<head lang="en">
    <meta charset="UTF-8">
    <link type="text/css" rel="stylesheet" href="bootstrap-3.2.0-dist\css\bootstrap.css"> <!--css file link in bootstrap folder-->
    <title>View Users</title>
</head>
<style>
    .login-panel {
        margin-top: 150px;
    }
    .table {
        margin-top: 50px;

    }

</style>

<body>

<div class="table-scrol">
    <h1 align="center">Questions from Students</h1>

<div class="table-responsive"><!--this is used for responsive display in mobile and other devices-->


    <table class="table table-bordered table-hover table-striped" style="table-layout: fixed">
        <thead>

        <tr>

            <th>User Id</th>
            <th>Title of Question</th>
            <th>Question</th>
            <th>Write your answer</th>
            <th>Do ypu want to Answer?</th>
        </tr>
        </thead>

        <?php
        include("database/db_conection.php");
        $view_users_query="SELECT id, tdoubt, edoubt FROM question";//select query for viewing users.
        $run=mysqli_query($dbcon,$view_users_query);//here run the sql query.

        while($row=mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.
        {
            $id=$row[0];
            $tdoubt=$row[1];
            $edoubt=$row[2];



        ?>

        <tr>
<!--here showing results in the table -->
            <td><?php echo $id;  ?></td>
            <td><?php echo $tdoubt;  ?></td>
            <td><?php echo $edoubt;  ?></td>
             <td><form role="form" method="post" action="student_queries.php">
            <input class="form-control" placeholder="Type your answer here" name="answerdoubt" type="text" autofocus>
            </form></td> 
            <td><input class="btn btn-lg btn-success btn-block" type="submit" value="Answer this" name="submitanswer" ></td> <!--btn btn-danger is a bootstrap button to show danger-->

            
            <!--btn btn-danger is a bootstrap button to show danger-->
        </tr>

        <?php } ?>

    </table>
        </div>
</div>

<?php

include("database/db_conection.php");//make connection here
if(isset($_POST['submitanswer']))
{
    $answer_id=$id;
    $answer_of_doubt=$_POST['answerdoubt'];
   
//insert the user into the database.
$answer_doubt="insert into question (answer) VALUE ('$answer_of_doubt') WHERE id='".$id."' ";
    if(mysqli_query($dbcon,$insert_doubt))
    {
        echo"<script>window.open('succ.html','_self')</script>";
    }

}





?>





</body>

</html>
